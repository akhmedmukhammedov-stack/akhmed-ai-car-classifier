"""Offline fine-tuning; validation selects weights, test is reporting only."""
import argparse, copy, csv, json, random, time
from pathlib import Path
import torch
from PIL import Image, ImageOps
from torchvision import transforms as T
from vision import ROOT, backbone, TRANSFORM

class Photos(torch.utils.data.Dataset):
    def __init__(self, rows, brands, augment=False):
        self.labels=[brands.index(r['brand']) for r in rows]
        self.images=[]
        for r in rows:
            with Image.open(ROOT/r['path']) as im:
                self.images.append(ImageOps.exif_transpose(im).convert('RGB').resize((256,256)))
        self.transform=T.Compose([T.RandomResizedCrop(224,scale=(.65,1),ratio=(.85,1.18)),
            T.RandomHorizontalFlip(),T.ColorJitter(.15,.15,.1,.02),T.ToTensor(),
            T.Normalize([.485,.456,.406],[.229,.224,.225])]) if augment else TRANSFORM
    def __len__(self): return len(self.labels)
    def __getitem__(self,i): return self.transform(self.images[i]),self.labels[i]

@torch.inference_mode()
def evaluate(net, head, loader, device, brands):
    net.eval(); head.eval(); loss=0; total=0; correct=0; accepted=0; accepted_correct=0
    matrix=torch.zeros(len(brands),len(brands),dtype=torch.long)
    for x,y in loader:
        logits=head(net(x.to(device))); y=y.to(device)
        loss+=float(torch.nn.functional.cross_entropy(logits,y,reduction='sum'))
        probs=logits.softmax(1); conf,pred=probs.max(1); ok=pred==y
        total+=len(y); correct+=int(ok.sum()); accepted+=int((conf>=.55).sum())
        accepted_correct+=int((ok & (conf>=.55)).sum())
        for a,b in zip(y.cpu(),pred.cpu()): matrix[a,b]+=1
    return {'n':total,'brand_accuracy':correct/total,'loss':loss/total,
      'coverage_at_055':accepted/total,'accuracy_including_unknown':accepted_correct/total,
      'accepted_accuracy':accepted_correct/accepted if accepted else None,
      'confusion_matrix':matrix.tolist()}

def main(epochs=12):
    random.seed(42); torch.manual_seed(42); torch.set_num_threads(4); start=time.time()
    device=torch.device('mps' if torch.backends.mps.is_available() else 'cpu')
    checkpoint=torch.load(ROOT/'models/brand.pt',map_location='cpu',weights_only=True)
    brands=checkpoint['brands']; net=backbone(); net.load_state_dict(checkpoint['backbone'])
    head=torch.nn.Linear(1024,len(brands)); head.load_state_dict(checkpoint['head'])
    # Keep generic early edges/textures; adapt later visual features to car makes.
    for name,p in net.named_parameters(): p.requires_grad=name.startswith(('stage3.','stage4.','conv5.'))
    net.to(device); head.to(device)
    rows=list(csv.DictReader((ROOT/'data/manifest.csv').open()))
    loaders={s:torch.utils.data.DataLoader(Photos([r for r in rows if r['split']==s],brands,s=='train'),
       batch_size=32,shuffle=s=='train',num_workers=0) for s in ('train','valid','test')}
    baseline=evaluate(net,head,loaders['valid'],device,brands)
    best_loss=baseline['loss']; best=copy.deepcopy(checkpoint); history=[]
    opt=torch.optim.AdamW([{'params':[p for p in net.parameters() if p.requires_grad],'lr':.00015},
                          {'params':head.parameters(),'lr':.0003}],weight_decay=.01)
    scheduler=torch.optim.lr_scheduler.CosineAnnealingLR(opt,epochs)
    print('Device:',device,'baseline validation:',baseline['brand_accuracy'],flush=True)
    for epoch in range(epochs):
        net.train(); head.train()
        # Frozen early BatchNorm statistics must stay frozen too.
        net.conv1.eval(); net.stage2.eval()
        loss_sum=0; count=0
        for x,y in loaders['train']:
            x,y=x.to(device),y.to(device); opt.zero_grad()
            loss=torch.nn.functional.cross_entropy(head(net(x)),y,label_smoothing=.05)
            loss.backward(); opt.step(); loss_sum+=float(loss.detach())*len(y); count+=len(y)
        scheduler.step(); metrics=evaluate(net,head,loaders['valid'],device,brands)
        history.append({'epoch':epoch+1,'train_loss':loss_sum/count,'valid':metrics})
        if metrics['loss']<best_loss:
            best_loss=metrics['loss']
            best={'brands':brands,'threshold':.55,'architecture':'ShuffleNetV2 x1.0 fine-tuned stages 3/4/5 + linear head',
                  'backbone':{k:v.detach().cpu().clone() for k,v in net.state_dict().items()},
                  'head':{k:v.detach().cpu().clone() for k,v in head.state_dict().items()}}
            torch.save(best,ROOT/'models/brand_candidate.pt')
        print(f"Epoch {epoch+1}/{epochs}: val {metrics['brand_accuracy']:.3f}, loss {metrics['loss']:.3f}, elapsed {time.time()-start:.0f}s",flush=True)
    net.load_state_dict(best['backbone']); head.load_state_dict(best['head'])
    results={s:evaluate(net,head,loaders[s],device,brands) for s in ('valid','test')}
    promoted=results['valid']['loss']<baseline['loss']
    if promoted:
        if not (ROOT/'models/brand_baseline.pt').exists():
            torch.save(checkpoint,ROOT/'models/brand_baseline.pt')
        torch.save(best,ROOT/'models/brand_new.pt')
        (ROOT/'models/brand_new.pt').replace(ROOT/'models/brand.pt')
    report={'brands':brands,'baseline_valid':baseline,'metrics':results,'history':history,
      'promoted':promoted,'device':str(device),'seconds':time.time()-start,'epochs':epochs,
      'augmentation':'random resized crop, horizontal flip, mild colour jitter',
      'selection':'minimum validation cross entropy, including unchanged baseline',
      'limitations':['Same source test images, not a street-photo benchmark.','No unknown-brand validation.','Colour accuracy not evaluated.','Chevrolet is not in this dataset.']}
    (ROOT/'reports/finetuning.json').write_text(json.dumps(report,indent=2))
    print(json.dumps({'promoted':promoted,'metrics':results}),flush=True)

if __name__=='__main__':
    parser=argparse.ArgumentParser(); parser.add_argument('--epochs',type=int,default=12)
    main(parser.parse_args().epochs)
