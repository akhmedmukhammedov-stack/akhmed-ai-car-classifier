"""Select a rejection threshold using validation predictions only."""
def choose_threshold(confidences, correct, precision=.9, min_accepted=100):
    if len(confidences) != len(correct):
        raise ValueError('Prediction lengths disagree')
    pairs = sorted(zip(confidences, correct), reverse=True)
    result = {'threshold': .55, 'calibrated': False, 'accepted': 0}
    hits = 0
    for i, (confidence, ok) in enumerate(pairs):
        hits += int(ok)
        if i + 1 < len(pairs) and pairs[i + 1][0] == confidence:
            continue
        n = i + 1
        if n >= min_accepted and hits / n >= precision:
            result = {'threshold': float(confidence), 'calibrated': True,
                      'accepted': n, 'correct': hits, 'precision': hits / n}
    return result
