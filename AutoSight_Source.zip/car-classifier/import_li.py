"""Add Li Auto crops from Alexans Workspace COCO export; group augmented originals."""
import csv, json, hashlib
from pathlib import Path
from collections import Counter, defaultdict
from PIL import Image
from core import safe_extract
ROOT=Path(__file__).resolve().parent
SOURCE='Roboflow Alexans Workspace object-detection-cyuno v1 CC BY 4.0'

def main(archive):
    dest=ROOT/'data/li_coco'; safe_extract(archive,dest)
    manifest=ROOT/'data/expanded_manifest.csv'
    rows=[r for r in csv.DictReader(manifest.open()) if r['source']!=SOURCE]
    parsed={s:json.loads((dest/s/'_annotations.coco.json').read_text()) for s in ['train','valid']}
    def group(im): return im.get('extra',{}).get('name',im['file_name'].split('.rf.')[0])
    val_groups=sorted({group(im) for im in parsed['valid']['images']},key=lambda k:hashlib.sha256(k.encode()).hexdigest())
    # No export test split: partition original validation groups before any fitting.
    val_split={g:('test' if i%2 else 'valid') for i,g in enumerate(val_groups)}
    hashes={r['sha256'] for r in rows}; added=[]
    for source_split in ['valid','train']:
        d=parsed[source_split]; ims={i['id']:i for i in d['images']}; cats={c['id']:c['name'] for c in d['categories']}
        for a in d['annotations']:
            if cats[a['category_id']]!='Li Auto': continue
            im=ims[a['image_id']]; key=group(im)
            if source_split=='train' and key in val_split: continue
            split='train' if source_split=='train' else val_split[key]
            image_path=(dest/source_split/im['file_name']).resolve()
            if not image_path.is_relative_to(dest.resolve()): raise ValueError('Invalid COCO image path')
            with Image.open(image_path) as pic:
                x,y,w,h=a['bbox']; box=(max(0,int(x)),max(0,int(y)),min(pic.width,int(x+w)),min(pic.height,int(y+h)))
                if box[2]-box[0]<24 or box[3]-box[1]<24: continue
                crop=pic.convert('RGB').crop(box)
                output=ROOT/'data/li_crops'/source_split/(Path(im['file_name']).stem+f"_{a['id']}.jpg")
                output.parent.mkdir(parents=True,exist_ok=True); crop.save(output,quality=95)
            digest=hashlib.sha256(output.read_bytes()).hexdigest()
            if digest in hashes: continue
            hashes.add(digest)
            r={'path':str(output.relative_to(ROOT)),'brand':'Li Auto','model':'','colour':'',
               'source':SOURCE,'source_split':source_split,'split':split,'sha256':digest}
            rows.append(r); added.append({'path':r['path'],'group':key,'split':split})
    with manifest.open('w') as f:
        writer=csv.DictWriter(f,fieldnames=list(rows[0])); writer.writeheader(); writer.writerows(rows)
    summary={'source':'https://universe.roboflow.com/alexans-workspace/object-detection-cyuno/dataset/1',
      'license':'CC BY 4.0','author':'Alexans Workspace','added':dict(Counter(r['split'] for r in added)),
      'original_groups':len({r['group'] for r in added}),'groups':added,
      'note':'Training export contains augmentations; counts are crops, not independent photos. Original validation groups split into validation/test.'}
    (ROOT/'reports/li_data.json').write_text(json.dumps(summary,indent=2))
    print({k:v for k,v in summary.items() if k!='groups'})
if __name__=='__main__':
    import sys; main(Path(sys.argv[1]))
