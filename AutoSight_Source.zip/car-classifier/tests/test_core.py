import unittest
import tempfile
import zipfile
from pathlib import Path
from core import brand_from_label, color_from_rgb, safe_extract, assign_splits

class CoreTests(unittest.TestCase):
    def test_brand_does_not_merge_independent_badges(self):
        self.assertEqual(brand_from_label('omoda_c5'), 'Omoda')
        self.assertEqual(brand_from_label('exeed_lx'), 'Exeed')
        self.assertEqual(brand_from_label('chert_arrizo_8'), 'Chery')
        with self.assertRaises(ValueError): brand_from_label('mystery_model')

    def test_eight_colour_classes_and_alias_colours(self):
        for rgb, expected in [((240,240,240),'white'), ((20,20,20),'black'),
            ((130,130,130),'grey'), ((210,30,30),'red'), ((30,50,210),'blue'),
            ((30,150,40),'green'), ((100,60,30),'brown'), ((240,200,20),'yellow'),
            ((255,120,0),'yellow')]:
            self.assertEqual(color_from_rgb(rgb), expected)

    def test_zip_cannot_write_outside_destination(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'bad.zip'
            with zipfile.ZipFile(p,'w') as z: z.writestr('../outside.txt','bad')
            with self.assertRaises(ValueError): safe_extract(p,Path(d)/'out')
            self.assertFalse((Path(d)/'outside.txt').exists())

    def test_identical_images_never_cross_splits(self):
        rows=[{'path':str(i),'brand':'BYD','sha256':str(i),'source_split':'train'} for i in range(12)]
        rows.append({'path':'copy','brand':'BYD','sha256':'0','source_split':'test'})
        result=assign_splits(rows)
        self.assertEqual(len(result),12)
        self.assertEqual(next(x for x in result if x['sha256']=='0')['split'],'test')
        self.assertTrue(any(x['split']=='valid' for x in result))
        self.assertTrue(any(x['split']=='train' for x in result))

if __name__=='__main__': unittest.main()
