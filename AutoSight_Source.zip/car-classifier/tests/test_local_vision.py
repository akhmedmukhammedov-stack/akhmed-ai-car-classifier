import unittest,json
from unittest.mock import patch
from PIL import Image
from ollama_backend import LocalVisionPipeline,parse_answer,BASE,MODEL
class LocalVisionTests(unittest.TestCase):
 def test_model_output_is_not_claimed_confidence(self):
  p=LocalVisionPipeline()
  with patch('ollama_backend.request',return_value={'message':{'content':json.dumps({'is_vehicle':True,'brand':'Chevrolet','model':'Nexia','colour':'white'})}}) as call:
   result=p.predict(Image.new('RGB',(100,60),'white'),mode='single')
  self.assertIsNone(result['cars'][0]['confidence']);self.assertEqual(result['cars'][0]['model'],'Nexia')
  self.assertEqual(BASE,'http://127.0.0.1:11434');self.assertNotIn('cloud',MODEL)
  self.assertIn('images',call.call_args.args[1]['messages'][0])
 def test_nonvehicle_is_not_added(self):
  with patch.object(LocalVisionPipeline,'classify',return_value={'is_vehicle':False,'brand':'unknown','model':'unknown','colour':'unknown'}):
   self.assertEqual(LocalVisionPipeline().predict(Image.new('RGB',(30,30)),mode='single')['cars'],[])
 def test_bad_json_rejected(self):
  with self.assertRaises(ValueError):parse_answer('{"brand":"Chevrolet"}')
