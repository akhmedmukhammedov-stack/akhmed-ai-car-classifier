import tempfile, unittest
from pathlib import Path
from unittest.mock import patch
import app

class ReloadTests(unittest.TestCase):
    def test_changed_weights_reload_but_unchanged_weights_reuse(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d); (root/'models').mkdir()
            for name in ('brand.pt','detector.pt'): (root/'models'/name).write_bytes(b'v1')
            with patch.object(app,'ROOT',root), patch.object(app,'pipeline',None), patch.object(app,'pipeline_signature',None,create=True), patch('vision.Pipeline') as factory:
                first=object(); second=object(); factory.side_effect=[first,second]
                self.assertIs(app.get_pipeline(),first)
                self.assertIs(app.get_pipeline(),first)
                (root/'models/brand.pt').write_bytes(b'new version')
                self.assertIs(app.get_pipeline(),second)
                self.assertEqual(factory.call_count,2)
