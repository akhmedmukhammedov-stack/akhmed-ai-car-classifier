import unittest
from unittest.mock import Mock
import torch
from PIL import Image
from vision import Pipeline, colour

class PredictionDetailsTests(unittest.TestCase):
    def test_uncertain_brand_keeps_ranked_alternatives(self):
        p=Pipeline.__new__(Pipeline)
        p.net=lambda x:x
        p.head=lambda x:torch.tensor([[0.,1.,2.,3.]])
        p.brands=['A','B','C','D'];p.threshold=.99
        p.detector=Mock(side_effect=AssertionError('not used'))
        car=p.predict(Image.new('RGB',(80,40),'white'),'single')['cars'][0]
        self.assertEqual(car['brand'],'unknown')
        self.assertEqual([x['brand'] for x in car.get('brand_candidates',[])],['D','C','B'])

    def test_mixed_paint_reports_ambiguity(self):
        from vision import colour_details
        im=Image.new('RGB',(100,100),'white')
        im.paste('black',(50,0,100,100))
        result=colour_details(im)
        self.assertTrue(result['colour_uncertain'])
        self.assertEqual({x['colour'] for x in result['colour_candidates'][:2]}, {'black','white'})
        for name in ('white','black','red','blue','green','yellow'):
            result=colour_details(Image.new('RGB',(100,100),name))
            self.assertEqual(result['colour'],name)
            self.assertFalse(result['colour_uncertain'])
