import csv, unittest
from pathlib import Path
from collections import defaultdict
from import_extra import ALIASES

class ExpandedDataTests(unittest.TestCase):
    def test_aliases_preserve_badges(self):
        self.assertEqual(ALIASES.get('Byd','Byd'),'BYD')
        for badge in ['Chevrolet','Daewoo','Omoda','Exeed','Jetour']:
            self.assertEqual(ALIASES.get(badge,badge),badge)
    @unittest.skipUnless(Path('data/expanded_manifest.csv').exists(),'Supplement not imported')
    def test_held_out_splits_and_label_consistency(self):
        with open('data/expanded_manifest.csv') as f: rows=list(csv.DictReader(f))
        hashes=defaultdict(set); labels=defaultdict(set); splits=defaultdict(set)
        for r in rows:
            hashes[r['sha256']].add(r['split']); labels[r['sha256']].add(r['brand']); splits[r['brand']].add(r['split'])
        self.assertTrue(all(len(v)==1 for v in hashes.values()))
        self.assertTrue(all(len(v)==1 for v in labels.values()))
        for brand in ['Changan','Chevrolet','BYD','Kia','Hyundai']:
            self.assertEqual(splits[brand],{'train','valid','test'})
