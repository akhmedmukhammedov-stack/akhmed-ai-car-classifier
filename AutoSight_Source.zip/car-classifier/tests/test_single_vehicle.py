import unittest
from unittest.mock import Mock
import torch
from PIL import Image
from vision import Pipeline
class SingleVehicleTests(unittest.TestCase):
 def test_fragment_bypasses_detector_and_can_abstain(self):
  p=Pipeline.__new__(Pipeline);p.detector=Mock(side_effect=AssertionError('Detector must not run'));p.net=lambda x:x;p.head=lambda x:torch.tensor([[0.,0.]])
  p.brands=['Chevrolet','Li Auto'];p.threshold=.8
  result=p.predict(Image.new('RGB',(80,40),'white'),mode='single')
  self.assertEqual(result['cars'][0]['brand'],'unknown')
  self.assertEqual(result['cars'][0]['box'],[0,0,80,40]);p.detector.assert_not_called()
 def test_invalid_mode_rejected(self):
  p=Pipeline.__new__(Pipeline)
  with self.assertRaises(ValueError):p.predict(Image.new('RGB',(80,40)),mode='invalid')
