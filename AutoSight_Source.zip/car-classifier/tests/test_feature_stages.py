import unittest
import torch
from vision import backbone
class StageTests(unittest.TestCase):
    def test_cached_prefix_matches_normal_backbone(self):
        from tune_expanded import prefix, suffix
        torch.set_num_threads(2); torch.manual_seed(1)
        model=backbone().eval(); x=torch.rand(2,3,64,64)
        with torch.inference_mode():
            self.assertTrue(torch.allclose(model(x),suffix(model,prefix(model,x)),atol=1e-6))
