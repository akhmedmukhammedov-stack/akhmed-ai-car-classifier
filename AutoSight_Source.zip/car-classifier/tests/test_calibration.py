import unittest
from calibration import choose_threshold
class CalibrationTests(unittest.TestCase):
    def test_chooses_largest_qualifying_prefix(self):
        r=choose_threshold([.95,.9,.8,.7],[True,True,False,False],precision=.9,min_accepted=2)
        self.assertEqual(r['threshold'],.9); self.assertEqual(r['accepted'],2)
    def test_equal_confidences_cannot_be_split(self):
        r=choose_threshold([.9,.9],[True,False],precision=.9,min_accepted=1)
        self.assertFalse(r['calibrated'])
    def test_no_claim_from_tiny_sample(self):
        self.assertFalse(choose_threshold([.99],[True],min_accepted=10)['calibrated'])
