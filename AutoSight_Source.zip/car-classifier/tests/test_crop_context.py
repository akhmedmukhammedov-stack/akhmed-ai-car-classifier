import unittest
from unittest.mock import patch
import torch
from PIL import Image
import vision
class CropContextTests(unittest.TestCase):
 def test_checkpoint_context_applies_to_brand_but_box_stays_tight(self):
  p=vision.Pipeline.__new__(vision.Pipeline);p.brands=['A','B'];p.threshold=.5;p.crop_margin=.25
  p.detector=lambda imgs:[{'boxes':torch.tensor([[20.,30.,60.,60.]]),'labels':torch.tensor([3]),'scores':torch.tensor([.9])}]
  p.net=lambda x:x;p.head=lambda x:torch.tensor([[0.,5.]])
  sizes=[]
  def transform(im):sizes.append(im.size);return torch.zeros(3,224,224)
  with patch.object(vision,'TRANSFORM',transform):out=p.predict(Image.new('RGB',(100,100),'white'))
  self.assertEqual(sizes,[(60,45)])
  self.assertEqual(out['cars'][0]['box'],[20,30,60,60])
