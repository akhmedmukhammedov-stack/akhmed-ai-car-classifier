"""Measure rejection/coverage; select threshold on validation, never on test."""
import csv, json
import torch
from PIL import Image, ImageOps
from calibration import choose_threshold
from vision import ROOT, TRANSFORM, backbone

@torch.no_grad()
def main():
    torch.set_num_threads(4)
    path = ROOT/'models/brand_expanded.pt'
    state = torch.load(path, map_location='cpu', weights_only=True)
    net = backbone().eval(); net.load_state_dict(state['backbone'])
    brands = state['brands']
    head = torch.nn.Linear(1024, len(brands)).eval(); head.load_state_dict(state['head'])
    rows = list(csv.DictReader((ROOT/'data/expanded_manifest.csv').open()))
    predictions = {}
    for split in ['valid', 'test']:
        subset = [r for r in rows if r['split'] == split]
        confs, oks = [], []
        for offset in range(0, len(subset), 32):
            batch, targets = [], []
            for row in subset[offset:offset+32]:
                with Image.open(ROOT/row['path']) as im:
                    batch.append(TRANSFORM(ImageOps.exif_transpose(im).convert('RGB')))
                targets.append(brands.index(row['brand']))
            conf, pred = head(net(torch.stack(batch))).softmax(1).max(1)
            confs.extend(conf.tolist()); oks.extend((pred == torch.tensor(targets)).tolist())
        predictions[split] = (torch.tensor(confs), torch.tensor(oks))
    selection = choose_threshold(*[v.tolist() for v in predictions['valid']])
    threshold = selection['threshold']; metrics = {}
    for split, (conf, ok) in predictions.items():
        accepted = conf >= threshold
        metrics[split] = {'n': len(ok), 'brand_accuracy': float(ok.float().mean()),
            'coverage': float(accepted.float().mean()),
            'accuracy_including_unknown': float((accepted & ok).float().mean()),
            'accepted_accuracy': float(ok[accepted].float().mean()) if accepted.any() else None}
    report_path = ROOT/'reports/expanded_training.json'
    report = json.loads(report_path.read_text())
    report['threshold_calibration'] = {**selection, 'target_validation_precision': .9,
        'selection_split': 'valid', 'limitation': 'Known brands only; rejection of unseen brands has not been validated.'}
    report['deployed_metrics'] = metrics
    state['threshold'] = threshold
    torch.save(state, path)
    report_path.write_text(json.dumps(report, indent=2))
    print(json.dumps({'threshold': threshold, 'metrics': metrics}), flush=True)

if __name__ == '__main__': main()
