"""Adapt late visual features to all badges, caching frozen early features on CPU."""
import copy, csv, json, time
import torch
from PIL import Image, ImageOps
from vision import ROOT, TRANSFORM, backbone

def prefix(net,x): return net.stage3(net.stage2(net.maxpool(net.conv1(x))))
def suffix(net,x): return net.conv5(net.stage4(x)).mean([2,3])

@torch.no_grad()
def evaluate(net,head,x,y,brands,rows):
    net.eval(); head.eval(); logits=torch.cat([head(suffix(net,b.float())) for b in x.split(64)])
    conf,pred=logits.softmax(1).max(1); ok=pred==y; accepted=conf>=.55
    cm=torch.zeros(len(brands),len(brands),dtype=torch.long)
    for a,b in zip(y,pred): cm[a,b]+=1
    by_source={}
    for source in sorted({r['source'] for r in rows}):
        mask=torch.tensor([r['source']==source for r in rows]); by_source[source]={'n':int(mask.sum()),'accuracy':float(ok[mask].float().mean())}
    return {'n':len(y),'loss':float(torch.nn.functional.cross_entropy(logits,y)),
      'brand_accuracy':float(ok.float().mean()),'coverage_at_055':float(accepted.float().mean()),
      'accuracy_including_unknown':float((ok & accepted).float().mean()),
      'accepted_accuracy':float(ok[accepted].float().mean()) if accepted.any() else None,
      'per_brand':{b:{'n':int((y==i).sum()),'accuracy':float(ok[y==i].float().mean())} for i,b in enumerate(brands)},
      'by_source':by_source,'confusion_matrix':cm.tolist()}

def main(epochs=4):
    start=time.time(); torch.manual_seed(42); torch.set_num_threads(4)
    checkpoint=torch.load(ROOT/'models/brand_expanded.pt',map_location='cpu',weights_only=True)
    brands=checkpoint['brands']; net=backbone().eval(); net.load_state_dict(checkpoint['backbone'])
    head=torch.nn.Linear(1024,len(brands)); head.load_state_dict(checkpoint['head'])
    rows=list(csv.DictReader((ROOT/'data/expanded_manifest.csv').open())); sets={}
    for split in ['train','valid','test']:
        subset=[r for r in rows if r['split']==split]; xs=[]; ys=[]
        for offset in range(0,len(subset),32):
            batch=[]
            for row in subset[offset:offset+32]:
                with Image.open(ROOT/row['path']) as im: batch.append(TRANSFORM(ImageOps.exif_transpose(im).convert('RGB')))
                ys.append(brands.index(row['brand']))
            with torch.no_grad(): xs.append(prefix(net,torch.stack(batch)).half())
            if offset%2048==0: print(f'Cache {split}: {offset}/{len(subset)}',flush=True)
        sets[split]=(torch.cat(xs),torch.tensor(ys),subset)
    for name,p in net.named_parameters(): p.requires_grad=name.startswith(('stage4.','conv5.'))
    opt=torch.optim.AdamW([{'params':[p for p in net.parameters() if p.requires_grad],'lr':.0001},
                          {'params':head.parameters(),'lr':.0002}],weight_decay=.01)
    x,y,_=sets['train']; counts=torch.bincount(y,minlength=len(brands)).float()
    criterion=torch.nn.CrossEntropyLoss(weight=(len(y)/(len(brands)*counts)).sqrt(),label_smoothing=.03)
    baseline=evaluate(net,head,*sets['valid'][:2],brands,sets['valid'][2]); best_loss=baseline['loss']; best=copy.deepcopy(checkpoint); history=[]
    print('Baseline validation:',baseline['brand_accuracy'],flush=True)
    for epoch in range(epochs):
        net.stage4.train(); net.conv5.train(); head.train()
        for idx in torch.randperm(len(y)).split(64):
            features=torch.nn.functional.dropout2d(x[idx].float(),p=.05,training=True)
            opt.zero_grad(); loss=criterion(head(suffix(net,features)),y[idx]); loss.backward(); opt.step()
        result=evaluate(net,head,*sets['valid'][:2],brands,sets['valid'][2])
        history.append({'epoch':epoch+1,'valid_accuracy':result['brand_accuracy'],'valid_loss':result['loss']})
        if result['loss']<best_loss:
            best_loss=result['loss']; best={'brands':brands,'threshold':.55,
              'architecture':'ShuffleNetV2 x1.0 car-fine-tuned with expanded-badge stage4/conv5 adaptation',
              'backbone':copy.deepcopy(net.state_dict()),'head':copy.deepcopy(head.state_dict())}
            torch.save(best,ROOT/'models/brand_tuning_progress.tmp')
            (ROOT/'models/brand_tuning_progress.tmp').replace(ROOT/'models/brand_tuning_progress.pt')
        print(f"Epoch {epoch+1}/{epochs}: validation {result['brand_accuracy']:.3f}, loss {result['loss']:.3f}, elapsed {time.time()-start:.0f}s",flush=True)
    net.load_state_dict(best['backbone']); head.load_state_dict(best['head'])
    metrics={s:evaluate(net,head,*sets[s][:2],brands,sets[s][2]) for s in ['valid','test']}
    prior=json.loads((ROOT/'reports/expanded_training.json').read_text())
    (ROOT/'reports/expanded_head_training.json').write_text(json.dumps(prior,indent=2))
    report={**prior,'metrics':metrics,'late_stage_tuning':{'epochs':epochs,'history':history,'seconds':time.time()-start,
      'baseline_valid':baseline['brand_accuracy'],'selection':'minimum validation cross entropy including unchanged head checkpoint',
      'augmentation':'5% spatial feature-channel dropout; cached FP16 early features',
      'learning_rates':{'stage4_conv5':.0001,'head':.0002}}}
    torch.save(best,ROOT/'models/brand_expanded.pt')
    (ROOT/'reports/expanded_training.json').write_text(json.dumps(report,indent=2))
    print(json.dumps({s:{k:m[k] for k in ['brand_accuracy','coverage_at_055','accuracy_including_unknown']} for s,m in metrics.items()}),flush=True)
if __name__=='__main__': main()
