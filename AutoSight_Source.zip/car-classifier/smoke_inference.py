"""Offline integration smoke test; this is not a street-photo accuracy benchmark."""
import csv, json, random, socket, time
from pathlib import Path
from PIL import Image
from vision import ROOT, Pipeline

def main():
    # Fail if inference attempts a network connection.
    def no_network(*args,**kwargs): raise AssertionError('Inference attempted a network connection')
    socket.socket.connect=no_network
    rows=list(csv.DictReader((ROOT/'data/expanded_manifest.csv').open()))
    chosen=[]; rng=random.Random(145)
    for brand in ['Changan','Chevrolet','BYD','Li Auto','Kia','Hyundai']:
        candidates=[r for r in rows if r['split']=='test' and r['brand']==brand]
        rng.shuffle(candidates); chosen.extend(candidates[:5])
    pipe=Pipeline(); records=[]
    for row in chosen:
        with Image.open(ROOT/row['path']) as pic:
            start=time.perf_counter(); result=pipe.predict(pic); elapsed=time.perf_counter()-start
        for c in result['cars']:
            assert c['colour'] in {'white','black','grey','red','blue','green','brown','yellow'}
            assert 0<=c['confidence']<=1
            x1,y1,x2,y2=c['box']; assert 0<=x1<x2<=result['width']; assert 0<=y1<y2<=result['height']
        dominant=max(result['cars'],key=lambda c:(c['box'][2]-c['box'][0])*(c['box'][3]-c['box'][1]),default=None)
        records.append({'path':row['path'],'dataset_label':row['brand'],'prediction':dominant,'seconds':elapsed,'detections':len(result['cars'])})
        print(row['brand'],dominant['brand'] if dominant else 'no detection',round(elapsed,2),flush=True)
    summary={'n':len(records),'network_disabled':True,'seconds_mean':sum(r['seconds'] for r in records)/len(records),
       'dominant_label_matches':sum(r['prediction'] is not None and r['prediction']['brand']==r['dataset_label'] for r in records),
       'limitations':'Small fixed sample of public-dataset test photos; largest detection compared with image label. Not ground-truth street detection or colour accuracy.',
       'records':records}
    (ROOT/'reports/inference_smoke.json').write_text(json.dumps(summary,indent=2))
    print({k:v for k,v in summary.items() if k!='records'},flush=True)
if __name__=='__main__': main()
