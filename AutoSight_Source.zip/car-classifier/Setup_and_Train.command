#!/bin/zsh
set -eu
printf "\033]0;Akhmed AI\007"
cd "${0:A:h}"
export TORCH_HOME="$PWD/models/cache"
if [[ ! -x .venv/bin/python ]]; then
  if [[ -x /opt/homebrew/bin/python3.10 ]]; then
    /opt/homebrew/bin/python3.10 -m venv .venv
  else
    python3 -m venv .venv
  fi
fi
if ! .venv/bin/python -m pip install -r requirements.txt; then
  echo 'Installation failed. Check internet connection; training has not started.'
  read '?Press Enter to close'; exit 1
fi
if [[ ! -f data/manifest.csv ]]; then
  echo 'Missing data/manifest.csv. Run prepare.py with the dataset ZIP first.'
  read '?Press Enter to close'; exit 1
fi
.venv/bin/python train.py
.venv/bin/python finetune.py
if [[ -f data/expanded_manifest.csv ]]; then
  .venv/bin/python expand_train.py
  .venv/bin/python tune_expanded.py
  .venv/bin/python calibrate_model.py
  .venv/bin/python promote_expanded.py
  if [[ -f reports/user_photo_review.json && -d data/user_review ]]; then
    .venv/bin/python adapt_crops.py
    .venv/bin/python promote_crop.py
  fi
fi
.venv/bin/python -m pip freeze > reports/environment.txt
echo 'Done. Open Start.command.'
read '?Press Enter to close'
