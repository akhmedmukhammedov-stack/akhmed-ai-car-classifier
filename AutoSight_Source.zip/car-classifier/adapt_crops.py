"""Fit a brand head on the same detector crops used in deployment."""
import csv,json,copy,time,random
import torch
from PIL import Image,ImageOps
from torchvision.transforms import RandomResizedCrop,RandomHorizontalFlip,ColorJitter,Compose,ToTensor,RandomPerspective,RandomApply,GaussianBlur
from vision import ROOT,Pipeline,TRANSFORM

from image_regions import classification_crop as crop_for_brand

def main():
 start=time.time();torch.manual_seed(42);torch.set_num_threads(4);p=Pipeline()
 original=torch.load(ROOT/'models/brand.pt',map_location='cpu',weights_only=True)
 rows=list(csv.DictReader((ROOT/'data/expanded_manifest.csv').open()));sets={}
 for split in ['train','valid','test']:
  rr=[r for r in rows if r['split']==split]
  if split != 'test':
   rng=random.Random(92);selected=[]
   for brand in p.brands:
    group=[r for r in rr if r['brand']==brand];rng.shuffle(group);selected.extend(group[:64 if split=='train' else 10])
   rr=selected
  xs=[];ys=[];found=[]
  for offset in range(0,len(rr),4):
   batch=[]
   for row in rr[offset:offset+4]:
    with Image.open(ROOT/row['path']) as im: batch.append(ImageOps.exif_transpose(im).convert('RGB'))
   with torch.inference_mode(): detections=p.detector([ToTensor()(im) for im in batch])
   crops=[]
   for im,det,row in zip(batch,detections,rr[offset:offset+4]):
    boxes=[b.tolist() for b,l,s in zip(det['boxes'],det['labels'],det['scores']) if int(l)==3 and float(s)>=.5 and float(b[2]-b[0])>=24 and float(b[3]-b[1])>=24]
    box=max(boxes,key=lambda b:(b[2]-b[0])*(b[3]-b[1]),default=None);found.append(box is not None)
    crops.append(TRANSFORM(crop_for_brand(im,box) if box else im));ys.append(p.brands.index(row['brand']))
   with torch.inference_mode(): xs.append(p.net(torch.stack(crops)))
   if offset%256==0:
    print(split,offset,len(rr),round(time.time()-start),flush=True)
    torch.save({'offset':offset+len(batch),'xs':xs,'ys':ys,'found':found},ROOT/f'data/crop_progress_{split}.pt')
  sets[split]=(torch.cat(xs),torch.tensor(ys),torch.tensor(found))
 # Fixed local-photo split: keep two white Cobalt views together; no Daewoo label guessing.
 own=json.loads((ROOT/'reports/user_photo_review.json').read_text())['files']
 test_names={'chevrolet_cobalt_white.jpg','chevrolet_cobalt_whitee.jpg','chevrolet_gentra_black.jpg'}
 valid_names={'chevrolet_onix_whitee.jpg'}
 augmentation=Compose([RandomResizedCrop(224,scale=(.75,1.)),RandomHorizontalFlip(),ColorJitter(.25,.2,.15,.02),RandomPerspective(distortion_scale=.15,p=.3),RandomApply([GaussianBlur(3,sigma=(.1,1.2))],p=.2)])
 ownsets={s:[] for s in ['train','valid','test']};split_report=[]
 for row in own:
  if row['brand']!='Chevrolet':continue
  name=ROOT.joinpath(row['path']).name;split='test' if name in test_names else 'valid' if name in valid_names else 'train'
  with Image.open(ROOT/row['path']) as f:im=ImageOps.exif_transpose(f).convert('RGB');im.thumbnail((1800,1800))
  with torch.inference_mode():d=p.detector([ToTensor()(im)])[0]
  boxes=[b.tolist() for b,l,s in zip(d['boxes'],d['labels'],d['scores']) if int(l)==3 and float(s)>=.5]
  box=max(boxes,key=lambda b:(b[2]-b[0])*(b[3]-b[1]),default=None);crop=crop_for_brand(im,box) if box else im
  ims=[TRANSFORM(augmentation(crop)) for _ in range(32)] if split=='train' else [TRANSFORM(crop)]
  with torch.inference_mode(): feats=p.net(torch.stack(ims))
  ownsets[split].append((feats,box is not None));split_report.append({'path':row['path'],'split':split,'brand':row['brand'],'detected':box is not None})
 torch.save({'public':sets,'own':ownsets,'brands':p.brands},ROOT/'data/crop_features.pt')
 head=copy.deepcopy(p.head); opt=torch.optim.AdamW(head.parameters(),lr=.0005,weight_decay=.02)
 x,y,found=sets['train'];localx=torch.cat([a for a,b in ownsets['train']]);x=torch.cat([x,localx]);y=torch.cat([y,torch.full((len(localx),),p.brands.index('Chevrolet'))])
 vx,vy,vfound=sets['valid'];ov=torch.cat([a for a,b in ownsets['valid']]);oi=p.brands.index('Chevrolet')
 def loss():
  with torch.no_grad():return float(torch.nn.functional.cross_entropy(head(vx),vy)+.01*torch.nn.functional.cross_entropy(head(ov),torch.full((len(ov),),oi)))
 best_loss=loss();best=copy.deepcopy(head.state_dict());history=[]
 for epoch in range(30):
  for idx in torch.randperm(len(y)).split(256):
   opt.zero_grad();l=torch.nn.functional.cross_entropy(head(x[idx]),y[idx],label_smoothing=.03);l.backward();opt.step()
  value=loss();history.append(value)
  if value<best_loss:best_loss=value;best=copy.deepcopy(head.state_dict())
  if epoch%10==0:print('head',epoch+1,value,flush=True)
 head.load_state_dict(best)
 from calibration import choose_threshold
 with torch.no_grad():vc,vp=head(vx).softmax(1).max(1)
 selection=choose_threshold(vc[vfound].tolist(),(vp[vfound]==vy[vfound]).tolist())
 metrics={}
 for split in ['valid','test']:
  sx,sy,sfound=sets[split]
  with torch.no_grad():c,pred=head(sx).softmax(1).max(1)
  ok=pred==sy;accepted=(c>=selection['threshold'])&sfound
  metrics[split]={'n':len(sy),'detection_coverage':float(sfound.float().mean()),'top1_including_detection_misses':float((ok&sfound).float().mean()),'coverage':float(accepted.float().mean()),'accuracy_including_unknown':float((ok&accepted).float().mean()),'accepted_accuracy':float(ok[accepted].float().mean()) if accepted.any() else None}
 original['head']=best;original['threshold']=selection['threshold'];original['crop_margin']=.25
 original['architecture']+='; runtime-crop-adapted head'
 torch.save(original,ROOT/'models/brand_crop_candidate.pt')
 report={'brands':p.brands,'sampling':{'train_per_brand_max':64,'valid_per_brand_max':10,'seed':92,'test':'entire original test split'},'metrics':metrics,'threshold_calibration':selection,'own_split':split_report,'own_capture_provenance':'User-supplied photos; personal capture not established.','selection':'minimum public validation cross entropy plus 0.01 local validation cross entropy; test unused for weight selection','history':history,'seconds':time.time()-start,'limitations':'Largest detected car compared against image label, not full multi-car detection ground truth. Local diagnostic images were previously inspected; local held-out sample is tiny.'}
 (ROOT/'reports/crop_training.json').write_text(json.dumps(report,indent=2));print(json.dumps(metrics),flush=True)
if __name__=='__main__':main()
