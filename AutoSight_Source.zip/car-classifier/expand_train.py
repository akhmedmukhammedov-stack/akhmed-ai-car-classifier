"""Train a expanded-brand head from local fine-tuned features, with independent held-out metrics."""
import csv, copy, json, time
import torch
from PIL import Image, ImageOps
from vision import ROOT, backbone, TRANSFORM

def main():
    torch.manual_seed(42); torch.set_num_threads(4); start=time.time()
    checkpoint=torch.load(ROOT/'models/brand.pt',map_location='cpu',weights_only=True)
    rows=list(csv.DictReader((ROOT/'data/expanded_manifest.csv').open()))
    brands=sorted({r['brand'] for r in rows if r['split']=='train'})
    device=torch.device('mps' if torch.backends.mps.is_available() else 'cpu')
    net=backbone().eval(); net.load_state_dict(checkpoint['backbone']); net.to(device)
    sets={}
    for split in ['train','valid','test']:
        subset=[r for r in rows if r['split']==split]; features=[]; labels=[]
        for offset in range(0,len(subset),32):
            images=[]
            for row in subset[offset:offset+32]:
                with Image.open(ROOT/row['path']) as im:
                    images.append(TRANSFORM(ImageOps.exif_transpose(im).convert('RGB')))
                labels.append(brands.index(row['brand']))
            with torch.inference_mode(): features.append(net(torch.stack(images).to(device)).cpu())
            if offset%1024==0: print(f'{split}: {offset}/{len(subset)}',flush=True)
        sets[split]=(torch.cat(features),torch.tensor(labels),subset)
    head=torch.nn.Linear(1024,len(brands))
    with torch.no_grad():
        for i,name in enumerate(checkpoint['brands']):
            j=brands.index(name); head.weight[j].copy_(checkpoint['head']['weight'][i]); head.bias[j].copy_(checkpoint['head']['bias'][i])
    opt=torch.optim.AdamW(head.parameters(),lr=.002,weight_decay=.02)
    x,y,_=sets['train']; vx,vy,_=sets['valid']; history=[]; best_loss=float('inf'); best=None
    counts=torch.bincount(y,minlength=len(brands)).float()
    loss_fn=torch.nn.CrossEntropyLoss(weight=(len(y)/(len(brands)*counts)).sqrt(),label_smoothing=.03)
    for epoch in range(120):
        head.train()
        for idx in torch.randperm(len(y)).split(256):
            opt.zero_grad(); loss=loss_fn(head(x[idx]),y[idx]); loss.backward(); opt.step()
        head.eval()
        with torch.inference_mode():
            logits=head(vx); loss=float(torch.nn.functional.cross_entropy(logits,vy)); acc=float((logits.argmax(1)==vy).float().mean())
        history.append({'epoch':epoch+1,'valid_loss':loss,'valid_accuracy':acc})
        if loss<best_loss: best_loss=loss; best=copy.deepcopy(head.state_dict())
        if epoch%20==0: print(f'Epoch {epoch+1}: val {acc:.3f}',flush=True)
    head.load_state_dict(best); metrics={}
    for split in ['valid','test']:
        sx,sy,subset=sets[split]
        with torch.inference_mode(): conf,pred=head(sx).softmax(1).max(1)
        ok=pred==sy; accepted=conf>=.55
        cm=torch.zeros(len(brands),len(brands),dtype=torch.long)
        for a,b in zip(sy,pred): cm[a,b]+=1
        source_metrics={}
        for source in sorted({r['source'] for r in subset}):
            mask=torch.tensor([r['source']==source for r in subset]); source_metrics[source]={'n':int(mask.sum()),'accuracy':float(ok[mask].float().mean())}
        metrics[split]={'n':len(sy),'brand_accuracy':float(ok.float().mean()),
          'coverage_at_055':float(accepted.float().mean()),'accuracy_including_unknown':float((ok & accepted).float().mean()),
          'accepted_accuracy':float(ok[accepted].float().mean()) if accepted.any() else None,
          'per_brand':{b:{'n':int((sy==i).sum()),'accuracy':float(ok[sy==i].float().mean())} for i,b in enumerate(brands)},
          'by_source':source_metrics,'confusion_matrix':cm.tolist()}
    output={'brands':brands,'threshold':.55,'architecture':'Car-fine-tuned ShuffleNetV2 x1.0 + expanded expanded-brand linear head',
        'backbone':net.cpu().state_dict(),'head':head.state_dict()}
    torch.save(checkpoint,ROOT/'models/brand_11brands.pt')
    torch.save(output,ROOT/'models/brand_expanded.pt')
    report={'brands':brands,'metrics':metrics,'history':history,'seconds':time.time()-start,
      'device':str(device),'selection':'minimum validation cross entropy over 120 head epochs',
      'learning_rate':.002,'optimizer':'AdamW','threshold':.55,'colour_accuracy':None,
      'limitations':['Not a phone/street benchmark.','No Daewoo or Jetour training examples.',
       'Own Tashkent photographs have not yet been imported.','Unknown-brand threshold not calibrated.','Near duplicate leakage not ruled out.']}
    (ROOT/'reports/expanded_training.json').write_text(json.dumps(report,indent=2))
    print(json.dumps({s:{k:v for k,v in m.items() if k not in ['per_brand','confusion_matrix']} for s,m in metrics.items()}),flush=True)
    print('Candidate saved as brand_expanded.pt; review metrics before promotion.',flush=True)
if __name__=='__main__': main()
