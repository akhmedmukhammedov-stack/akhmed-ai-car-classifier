"""Validate and install a crop-adapted checkpoint, retaining the prior model."""
import shutil, json
import torch
from vision import ROOT, backbone

def main():
    candidate=ROOT/'models/brand_crop_candidate.pt'
    state=torch.load(candidate,map_location='cpu',weights_only=True)
    report=json.loads((ROOT/'reports/crop_training.json').read_text())
    assert state['brands']==report['brands'] and state['crop_margin']==.25
    backbone().load_state_dict(state['backbone'])
    torch.nn.Linear(1024,len(state['brands'])).load_state_dict(state['head'])
    assert 0<=state['threshold']<=1
    assert all(torch.isfinite(v).all() for section in ['backbone','head'] for v in state[section].values())
    backup=ROOT/'models/brand_before_crop.pt'
    if not backup.exists():shutil.copyfile(ROOT/'models/brand.pt',backup)
    shutil.copyfile(candidate,ROOT/'models/brand_installing.pt')
    (ROOT/'models/brand_installing.pt').replace(ROOT/'models/brand.pt')
    print('Installed crop-adapted model:',len(state['brands']),'brands; threshold',state['threshold'])

if __name__=='__main__':main()
