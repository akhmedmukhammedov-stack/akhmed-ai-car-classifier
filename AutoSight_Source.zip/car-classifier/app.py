"""Loopback-only UI. No cloud inference or automatic model downloads."""
import base64, io, json, time, webbrowser, os
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path

ROOT=Path(__file__).resolve().parent
pipeline=None
pipeline_signature=None

def get_pipeline():
    """Reload local weights after a completed, atomic training update."""
    global pipeline, pipeline_signature
    if os.environ.get('AKHMED_ENGINE')=='ollama':
        if pipeline is None or pipeline_signature!=('ollama',):
            from ollama_backend import LocalVisionPipeline
            pipeline=LocalVisionPipeline();pipeline_signature=('ollama',)
        return pipeline
    from vision import Pipeline
    signature=tuple((p.stat().st_mtime_ns,p.stat().st_size)
        for p in (ROOT/'models/brand.pt',ROOT/'models/detector.pt'))
    if pipeline is None or signature!=pipeline_signature:
        replacement=Pipeline()
        pipeline=replacement
        pipeline_signature=signature
    return pipeline

class Handler(BaseHTTPRequestHandler):
    def respond(self,obj,status=200):
        data=json.dumps(obj,ensure_ascii=False).encode()
        self.send_response(status); self.send_header('Content-Type','application/json; charset=utf-8')
        self.send_header('Content-Length',str(len(data))); self.end_headers(); self.wfile.write(data)
    def do_GET(self):
        if self.path=='/api/status':
            if os.environ.get('AKHMED_ENGINE')=='ollama':
                from ollama_backend import status
                return self.respond(status())
            ready=all((ROOT/'models'/f).exists() for f in ['brand.pt','detector.pt'])
            return self.respond({'ready':ready})
        if self.path!='/': return self.respond({'error':'Not found'},404)
        data=(ROOT/'static'/'index.html').read_bytes()
        self.send_response(200); self.send_header('Content-Type','text/html; charset=utf-8')
        self.send_header('Content-Length',str(len(data))); self.end_headers(); self.wfile.write(data)
    def do_POST(self):
        if self.path!='/api/predict': return self.respond({'error':'Not found'},404)
        if self.headers.get('Origin') not in (None,'http://127.0.0.1:8765','http://localhost:8765'):
            return self.respond({'error':'Origin not allowed'},403)
        try:
            size=int(self.headers.get('Content-Length','0'))
            if not 0<size<=25_000_000: return self.respond({'error':'Фото должно быть меньше 18 МБ.'},413)
            payload=json.loads(self.rfile.read(size)); raw=base64.b64decode(payload['image'],validate=True)
            from PIL import Image, ImageOps
            start=time.perf_counter()
            active_pipeline=get_pipeline()
            with Image.open(io.BytesIO(raw)) as im:
                im=ImageOps.exif_transpose(im).convert('RGB'); im.thumbnail((1800,1800))
                result=active_pipeline.predict(im,mode=payload.get('mode','street'))
                buf=io.BytesIO(); im.save(buf,format='JPEG',quality=90)
            result['image']=base64.b64encode(buf.getvalue()).decode()
            result['seconds']=round(time.perf_counter()-start,2)
            self.respond(result)
        except ModuleNotFoundError:
            self.respond({'error':'Сначала запустите Setup_and_Train.command: библиотеки ещё не установлены.'},503)
        except Exception as e:
            self.respond({'error':str(e)},400)

if __name__=='__main__':
    server=HTTPServer(('127.0.0.1',8765),Handler)
    print('Open http://127.0.0.1:8765 — Ctrl+C to stop',flush=True)
    webbrowser.open('http://127.0.0.1:8765')
    try: server.serve_forever()
    except KeyboardInterrupt: server.server_close()
