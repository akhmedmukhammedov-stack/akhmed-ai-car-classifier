"""Install the verified local expanded checkpoint atomically; retain the prior model."""
import json, shutil
import torch
from vision import ROOT, backbone

def main():
    candidate=ROOT/'models/brand_expanded.pt'
    state=torch.load(candidate,map_location='cpu',weights_only=True)
    report=json.loads((ROOT/'reports/expanded_training.json').read_text())
    if state['brands']!=report['brands']: raise ValueError('Report/checkpoint labels disagree')
    backbone().load_state_dict(state['backbone'])
    torch.nn.Linear(1024,len(state['brands'])).load_state_dict(state['head'])
    if not all(torch.isfinite(v).all() for section in ['backbone','head'] for v in state[section].values()):
        raise ValueError('Nonfinite weights')
    shutil.copyfile(candidate,ROOT/'models/brand_installing.pt')
    (ROOT/'models/brand_installing.pt').replace(ROOT/'models/brand.pt')
    print('Installed',len(state['brands']),'brands; validation:',report['metrics']['valid']['brand_accuracy'])
if __name__=='__main__': main()
