import sys,csv,json,random
from pathlib import Path
sys.path.insert(0,str(Path.cwd()))
from vision import Pipeline,ROOT,TRANSFORM
from PIL import Image,ImageOps
import torch
p=Pipeline();rows=list(csv.DictReader((ROOT/'data/expanded_manifest.csv').open()));rng=random.Random(24);selected=[]
for brand in p.brands:
 rr=[r for r in rows if r['split']=='valid' and r['brand']==brand];rng.shuffle(rr);selected.extend(rr[:5])
counts={str(m):{'n':0,'top1':0,'accepted_correct':0} for m in [0,.25,.5,1]}
with torch.inference_mode():
 for row in selected:
  with Image.open(ROOT/row['path']) as f: im=ImageOps.exif_transpose(f).convert('RGB')
  result=p.predict(im);car=max(result['cars'],key=lambda c:(c['box'][2]-c['box'][0])*(c['box'][3]-c['box'][1]),default=None)
  for m in [0,.25,.5,1]:
   c=counts[str(m)];c['n']+=1
   if car is None:continue
   x1,y1,x2,y2=car['box'];w=x2-x1;h=y2-y1
   crop=im.crop((max(0,int(x1-m*w)),max(0,int(y1-m*h)),min(im.width,int(x2+m*w)),min(im.height,int(y2+m*h))))
   conf,idx=p.head(p.net(TRANSFORM(crop).unsqueeze(0))).softmax(1)[0].max(0)
   ok=p.brands[int(idx)]==row['brand'];c['top1']+=int(ok);c['accepted_correct']+=int(ok and float(conf)>=p.threshold)
print(json.dumps(counts,indent=2))
(ROOT/'reports/framing_validation.json').write_text(json.dumps({'split':'valid','seed':24,'per_brand_max':5,'results':counts},indent=2))
