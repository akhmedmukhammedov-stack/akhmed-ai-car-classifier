"""Shared training/inference image geometry."""
def classification_crop(image, box, margin=0.25):
    x1, y1, x2, y2 = box
    w, h = x2-x1, y2-y1
    return image.crop((max(0, int(x1-margin*w)), max(0, int(y1-margin*h)),
                       min(image.width, int(x2+margin*w)), min(image.height, int(y2+margin*h))))
