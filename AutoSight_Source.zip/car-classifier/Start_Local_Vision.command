#!/bin/zsh
set -eu
printf '\033]0;Akhmed AI\007'
cd "${0:A:h}"
export OLLAMA_HOST=127.0.0.1:11434
export OLLAMA_NO_CLOUD=1
export AKHMED_ENGINE=ollama
ollama_bin="$(command -v ollama || true)"
if [[ -z "$ollama_bin" ]]; then
 for candidate in /Applications/Ollama.app/Contents/Resources/ollama "$HOME/Applications/Ollama.app/Contents/Resources/ollama"; do
  if [[ -x "$candidate" ]]; then ollama_bin="$candidate"; break; fi
 done
fi
if [[ -z "$ollama_bin" ]]; then
 echo 'Один раз установи Ollama с официального сайта, затем снова запусти этот файл.'
 open https://ollama.com/download/mac
 read '?Нажми Enter для выхода'; exit 1
fi
if [[ ! -x .venv/bin/python ]]; then
 echo 'Нужны Python и библиотеки из requirements.txt; смотри README_RU.md.'
 read '?Нажми Enter для выхода'; exit 1
fi
mkdir -p reports
if ! "$ollama_bin" list >/dev/null 2>&1; then
 "$ollama_bin" serve > reports/ollama_server.log 2>&1 &
 for attempt in {1..30}; do
  if "$ollama_bin" list >/dev/null 2>&1; then break; fi
  sleep 1
 done
fi
if ! "$ollama_bin" list | awk '{print $1}' | grep -qx 'qwen3-vl:4b'; then
 echo 'Первая установка: скачивается локальная модель (~3.3 ГБ). Нужен интернет только для загрузки.'
 "$ollama_bin" pull qwen3-vl:4b
fi
echo 'Akhmed AI: готовая Qwen3-VL, локальный запуск. Для новой версии останови старый сервер через Ctrl+C.'
.venv/bin/python app.py
