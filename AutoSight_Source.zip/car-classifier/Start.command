#!/bin/zsh
set -eu
printf "\033]0;Akhmed AI\007"
cd "${0:A:h}"
if [[ ! -x .venv/bin/python ]]; then
  echo 'First run Setup_and_Train.command.'
  read '?Press Enter to close'; exit 1
fi
.venv/bin/python app.py
