"""Convert Roboflow model folders to a reproducible brand manifest."""
import argparse, csv, hashlib, json
from pathlib import Path
from collections import Counter
from core import safe_extract, brand_from_label, assign_splits

ROOT=Path(__file__).resolve().parent

def prepare(archive):
    out=ROOT/'data'/'china_cars'
    safe_extract(archive,out)
    rows=[]
    for p in sorted(out.rglob('*.jpg')):
        parts=p.relative_to(out).parts
        if len(parts)!=3 or parts[0] not in ('train','valid','test'): continue
        rows.append({'path':str(p.relative_to(ROOT)), 'brand':brand_from_label(parts[1]),
            'model':parts[1], 'colour':'', 'source':'Roboflow Prycoldes China_cars v8',
            'source_split':parts[0], 'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
    rows=assign_splits(rows)
    with (ROOT/'data'/'manifest.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)
    summary={'images':len(rows),'brands':dict(Counter(x['brand'] for x in rows)),
        'splits':dict(Counter(x['split'] for x in rows)),
        'source':'https://universe.roboflow.com/prycoldes/china_cars/dataset/8',
        'notes':['Colour labels not provided.','Exact duplicates removed; near duplicates not yet reviewed.',
                 'Public supplementary data; own Tashkent data still required.']}
    (ROOT/'reports'/'data_summary.json').write_text(json.dumps(summary,indent=2))
    print(json.dumps(summary,indent=2))

if __name__=='__main__':
    ap=argparse.ArgumentParser(); ap.add_argument('archive'); a=ap.parse_args(); prepare(a.archive)
