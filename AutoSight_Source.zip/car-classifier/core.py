"""Dependency-free label, colour and dataset integrity helpers."""
import colorsys
import random
import zipfile
from collections import defaultdict
from pathlib import Path

BRANDS = {'bmw':'BMW','changan':'Changan','chery':'Chery','chert':'Chery',
 'exeed':'Exeed','gac':'GAC','geely':'Geely','haval':'Haval','jaecoo':'Jaecoo',
 'omoda':'Omoda','tank':'Tank','zeekr':'Zeekr','byd':'BYD','chevrolet':'Chevrolet',
 'daewoo':'Daewoo','li':'Li Auto','kia':'Kia','hyundai':'Hyundai'}

def brand_from_label(label):
    key=label.lower().split('_')[0]
    if key not in BRANDS: raise ValueError('Unknown brand label: '+label)
    return BRANDS[key]

def color_from_rgb(rgb):
    h,s,v=colorsys.rgb_to_hsv(*(x/255 for x in rgb))
    h*=360
    if v<0.22: return 'black'
    if s<0.16: return 'white' if v>0.77 else 'grey'
    if s<0.32 and v>0.72: return 'brown' if 20<h<65 else 'grey'
    if h<15 or h>=345: return 'red'
    if h<65: return 'brown' if v<0.62 else 'yellow'
    if h<175: return 'green'
    if h<290: return 'blue'
    return 'red'

def safe_extract(archive, destination):
    destination=Path(destination).resolve()
    with zipfile.ZipFile(archive) as z:
        for info in z.infolist():
            target=(destination/info.filename).resolve()
            if not target.is_relative_to(destination): raise ValueError('Unsafe ZIP member')
            if (info.external_attr >> 16) & 0o170000 == 0o120000: raise ValueError('ZIP symlink')
        z.extractall(destination)

def assign_splits(rows):
    # Keep supplied test images held out, including byte-identical duplicates.
    unique={}
    for row in sorted(rows,key=lambda r:r['source_split']!='test'):
        old=unique.get(row['sha256'])
        if old and old['brand']!=row['brand']: raise ValueError('Conflicting duplicate labels')
        unique.setdefault(row['sha256'],dict(row))
    groups=defaultdict(list); result=[]
    for row in unique.values():
        if row['source_split']=='test':
            row['split']='test'; result.append(row)
        else: groups[row['brand']].append(row)
    rng=random.Random(42)
    for brand, group in sorted(groups.items()):
        group.sort(key=lambda r:r['path']); rng.shuffle(group)
        n=max(1,round(len(group)*0.2)) if len(group)>1 else 0
        for i,row in enumerate(group):
            row['split']='valid' if i<n else 'train'; result.append(row)
    return sorted(result,key=lambda r:r['path'])
