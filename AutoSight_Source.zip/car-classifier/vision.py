"""Offline detector, fine-tuned brand classifier, and colour heuristic."""
from pathlib import Path
from collections import Counter
import torch
import numpy as np
from PIL import Image, ImageOps
from torchvision.models import shufflenet_v2_x1_0
from torchvision.models.detection import ssdlite320_mobilenet_v3_large
from torchvision.transforms import Compose, Resize, ToTensor, Normalize
from core import color_from_rgb
from image_regions import classification_crop

ROOT=Path(__file__).resolve().parent
TRANSFORM=Compose([Resize((224,224)),ToTensor(),Normalize([.485,.456,.406],[.229,.224,.225])])

def backbone():
    net=shufflenet_v2_x1_0(weights=None)
    net.fc=torch.nn.Identity()
    return net

def colour(image):
    return colour_details(image)['colour']

def colour_details(image):
    # Approximate paint region; NOT segmentation. Glass/shadows can cause errors.
    w,h=image.size
    patch=image.crop((int(.15*w),int(.43*h),int(.85*w),max(int(.82*h),1))).resize((48,32))
    pixels=np.asarray(patch.convert('RGB')).reshape(-1,3)
    counts=Counter(color_from_rgb(tuple(int(v) for v in p)) for p in pixels)
    ranked=counts.most_common(3)
    share=ranked[0][1]/len(pixels)
    return {'colour':ranked[0][0], 'colour_uncertain':share<.6,
        'colour_candidates':[{'colour':name,'pixel_share':round(n/len(pixels),3)} for name,n in ranked]}

class Pipeline:
    def brand_details(self,probs):
        values,indices=probs.topk(min(3,len(self.brands)))
        candidates=[{'brand':self.brands[int(i)],'score':round(float(v),3)} for v,i in zip(values,indices)]
        return {'brand':candidates[0]['brand'] if float(values[0])>=self.threshold else 'unknown',
            'confidence':round(float(values[0]),3),'brand_candidates':candidates}

    def __init__(self):
        torch.set_num_threads(4)
        model_path=ROOT/'models'/'brand.pt'
        det_path=ROOT/'models'/'detector.pt'
        if not model_path.exists() or not det_path.exists():
            raise RuntimeError('Модель ещё не обучена. Запустите Setup_and_Train.command.')
        # Only load locally produced state dictionaries, never execute downloaded code.
        checkpoint=torch.load(model_path,map_location='cpu',weights_only=True)
        self.brands=checkpoint['brands']; self.threshold=checkpoint['threshold']
        self.crop_margin=checkpoint.get('crop_margin',0)
        self.net=backbone().eval(); self.net.load_state_dict(checkpoint['backbone'])
        self.head=torch.nn.Linear(1024,len(self.brands)).eval()
        self.head.load_state_dict(checkpoint['head'])
        self.detector=ssdlite320_mobilenet_v3_large(weights=None,weights_backbone=None).eval()
        self.detector.load_state_dict(torch.load(det_path,map_location='cpu',weights_only=True))

    @torch.inference_mode()
    def predict(self,image,mode='street'):
        if mode not in ('street','single'):
            raise ValueError('Неизвестный режим фотографии.')
        image=ImageOps.exif_transpose(image).convert('RGB')
        image.thumbnail((1800,1800))
        if mode=='single':
            # User explicitly confirms one vehicle/fragment; never auto-trigger on an empty street.
            probs=self.head(self.net(TRANSFORM(image).unsqueeze(0))).softmax(1)[0]
            return {'cars':[{**self.brand_details(probs),**colour_details(image),
                'box':[0,0,image.width,image.height]}],'width':image.width,'height':image.height,
                'assumed_single_vehicle':True}
        detection=self.detector([ToTensor()(image)])[0]
        result=[]
        for box, label, score in zip(detection['boxes'], detection['labels'], detection['scores']):
            # COCO car only: buses and trucks are not silently treated as cars.
            if int(label)!=3 or float(score)<.5: continue
            x1,y1,x2,y2=box.tolist()
            x1=max(0,int(x1)); y1=max(0,int(y1)); x2=min(image.width,int(x2)); y2=min(image.height,int(y2))
            if x2-x1<24 or y2-y1<24: continue
            crop=image.crop((x1,y1,x2,y2))
            brand_crop=classification_crop(image,(x1,y1,x2,y2),self.crop_margin)
            features=self.net(TRANSFORM(brand_crop).unsqueeze(0))
            probs=self.head(features).softmax(1)[0]
            result.append({**self.brand_details(probs),**colour_details(crop),
                'box':[x1,y1,x2,y2]})
        return {'cars':result,'width':image.width,'height':image.height}
