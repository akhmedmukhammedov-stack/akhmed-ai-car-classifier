# Akhmed AI / AutoSight

Local car badge and colour recognition for the CSAI-3210 midterm. This is an experimental trained model; it does not guarantee recognition of arbitrary vehicles.

## Launch on this Mac

Double-click `Start.command`. Terminal is titled **Akhmed AI**. Keep it open. Visit http://127.0.0.1:8765, choose a JPEG/PNG/WebP and click Recognize. Convert HEIC to JPEG first. If an older server is running, stop it with Ctrl+C and launch again once to load updated application code. Thereafter the server reloads local model weights when they change.

Use `Start.command` for recognition; `Setup_and_Train.command` repeats installation and training. No paid services or remote inference are used. Rehearse with Wi-Fi off and with a phone photograph of a screen.

## Data

The current training inventory combines these supplements:

- **Prycoldes, China_cars v8:** 3,021 photographs, 25 models mapped to 11 badges; page declares Public Domain. https://universe.roboflow.com/prycoldes/china_cars/dataset/8
- **pnh, car_brand v1:** 10,253 photographs, 22 badges, CC BY 4.0. Includes Chevrolet, BYD, Kia and Hyundai. https://universe.roboflow.com/training-kbu2h/car_brand-tuwiw/dataset/1
- **Alexans Workspace, object-detection-cyuno v1:** Li Auto bounding-box crops, CC BY 4.0. The export contains augmented training images; our 152 crops represent 62 original filename groups. 133 train, 9 validation, 10 test. https://universe.roboflow.com/alexans-workspace/object-detection-cyuno/dataset/1

Attribution is retained here and in reports. Downloaded photographs were extracted unchanged except Li Auto crops, made from supplied bounding boxes and saved as JPEG. Twelve user-provided photographs from Downloads/chevrolet are now copied to data/user_review for an independent diagnostic. Visual badge review found nine Chevrolet, one Daewoo and two unverified labels. For crop adaptation, five confirmed Chevrolet photos are used for training, one for validation, and three are held out; the other three images remain diagnostic only. Personal capture and Tashkent provenance are not established for every photo. The local test is tiny and was inspected earlier, so it is not a blind accuracy benchmark. Public data does not replace the assignment's own-photo requirement. Chevrolet examples include overseas models, so performance on Cobalt/Gentra/Nexia needs separate testing. Daewoo and Jetour remain missing.

`data/manifest.csv` is the original China_cars split; `data/expanded_manifest.csv` is the 33-brand inventory. SHA-256 duplicate checks prevent byte-identical samples crossing splits. The supplement preserves its supplied train/validation/test split. Li Auto preserves original filename groups, excludes training groups present in validation, and partitions original validation images into validation/test before fitting. Near-duplicate and same-car leakage has not been ruled out.

Badge labels remain separate: Chevrolet vs Daewoo, Chery vs Exeed vs Omoda vs Jetour. A class name or standalone logo does not supply vehicle training examples. Only the labels stored in `models/brand.pt` are supported by the active checkpoint.

## Model and evaluation

**Final deployment measurements:** `reports/crop_training.json`, `reports/inference_smoke.json`, and `reports/user_photo_results.json`. Earlier reports describe intermediate models and must not be presented as current end-to-end accuracy.


COCO SSDLite320 MobileNetV3 finds cars. Each crop is classified using a ShuffleNetV2 x1.0 backbone and a locally trained linear head. The original frozen ImageNet baseline achieved 67.97% top-1 brand accuracy on 306 China_cars test images.

`finetune.py` adapts stages 3/4/5 of the backbone on the 11-brand dataset with random resized crops, horizontal flips and mild colour jitter. AdamW: backbone LR 0.00015, head LR 0.0003, cosine schedule, weight decay 0.01, label smoothing 0.05, batch 32, 12 epochs. Earlier feature layers and their BatchNorm statistics stay frozen. The unchanged baseline is eligible during validation selection.

`expand_train.py` extracts those fine-tuned features for all 33 brands and trains a new head for 120 epochs using AdamW (LR 0.002, weight decay 0.02), square-root inverse-frequency class weights and 0.03 label smoothing. Minimum validation cross entropy selects weights; test results are reporting only.

`tune_expanded.py` then adapts stage4/conv5 and the head to the expanded labels for four epochs. Early features are cached as FP16, with 5% feature-channel dropout during fitting; this keeps CPU training inexpensive. It selects against the unchanged head checkpoint using validation loss. `reports/expanded_head_training.json` retains the earlier head-only measurements.

Actual measurements, confusion matrices and limitations are in `reports/training.json`, `reports/finetuning.json`, and `reports/expanded_training.json`. The expanded report includes per-brand and per-source scores, coverage at threshold 0.55, accuracy counting unknown answers as failures, and accuracy among accepted answers. Top-1 accuracy alone is not the accuracy of the deployed system with unknown rejection.

`calibrate_model.py` selects the highest-coverage confidence cutoff achieving at least 90% precision on accepted **known-brand validation images**, with at least 100 accepted samples. It reports held-out test coverage and accuracy separately in `deployed_metrics`. This does not establish 90% accuracy on all photos or validate rejection of unknown brands.

Colour is a custom HSV vote in a central-lower image region, not paint segmentation. Supported colours: white, black, grey/silver, red, blue, green, brown/beige/gold, yellow/orange. Colour accuracy and phone/street accuracy have not been measured. Confidence scores are not calibrated probabilities of correctness.

`adapt_crops.py` fixes the training/inference framing mismatch: it uses the same detector and a 25% context margin for brand classification. Display boxes and colour regions remain tight. The already fine-tuned backbone stays frozen; the head adapts using at most 64 public training images per brand and five local Chevrolet photographs with 32 random augmentations each. Validation uses at most 10 public images per brand plus one local photo (0.01 loss weight). Selection uses validation loss over 30 epochs, with the original head eligible. The complete 848-image public test split is held out. Missing detections and unknown answers count as failures in the reported deployed accuracy. Sources are image-labelled, so this is still not full multi-car street ground truth.

## Reproduce

Python 3.10 and requirements.txt are used. Initial installation/generic weights require internet; inference loads only local state dictionaries with `weights_only=True`.

```sh
python prepare.py /path/to/China_cars.v8-25_classes.folder.zip
python import_extra.py /path/to/car_brand.v1i.folder.zip
python import_li.py '/path/to/Object Detection.v1i.coco.zip'
python train.py
python finetune.py --epochs 12
python expand_train.py
python tune_expanded.py
python calibrate_model.py
python promote_expanded.py
# With the included user_photo_review.json and data/user_review:
python adapt_crops.py
python promote_crop.py
python app.py
```

Use `.venv/bin/python` on this Mac. `Setup_and_Train.command` performs training for already-imported data. Keep the source archives to reproduce the manifests. Tests: `python -m unittest discover -s tests -v`.

The delivery archive contains source, reports and active inference weights, and the 12 user-provided diagnostic photos, but excludes the environment and public photo datasets. Dataset source links above provide the data; install dependencies when moving to another machine.

## Submission and integrity

See `REQUIREMENTS.md`. Still required: verified own Tashkent photographs, colour evaluation, phone-screen tests, architecture uniqueness check, PDF of at most six pages, actual GitHub repository/history and `midterm` tag. Do not fabricate data collection, metrics or commit history.

This project was substantially generated and debugged with ChatGPT/Codex assistance, including model/training choices, interface, data processing and tests. Disclose this in the report and be able to explain the implementation. The application's display name does not alter this disclosure.
