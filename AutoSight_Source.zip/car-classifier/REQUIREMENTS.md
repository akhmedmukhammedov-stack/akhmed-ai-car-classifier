# Midterm constraints and current gaps

The target is a photograph of a Tashkent street, including multiple identifiable cars. Return one (badge brand, colour) pair per car. Do not infer the parent manufacturer as the badge. Chevrolet and Daewoo are distinct; Chery, Exeed, Omoda and Jetour are distinct.

Run locally with no internet, remote inference/API, cloud or AI assistant during the live test. Generic pretrained feature extractors/detectors are allowed; the brand classifier must be trained/fine-tuned on the project data. Public datasets supplement, rather than replace, own Tashkent phone photographs. Architecture uniqueness against other teams remains to be confirmed by the student.

Eight output colours: white, black, grey (including silver), red, blue, green, brown (including beige/gold), yellow (including orange).

Live evaluation: 20 unseen photos; at least half feature Chinese brands; two minutes per photo. Incorrect extra predictions are penalized. Brand and colour both matter. No complete guaranteed list of test brands has been established here.

Training data currently cover 33 badges after merging China_cars v8 and pnh car_brand v1, plus Li Auto crops from Alexans Workspace. That does not imply that a trained 33-class checkpoint has passed evaluation: consult reports/expanded_training.json and models/brand.pt.

Critical coverage gaps: Daewoo and Jetour. Li Auto coverage is small. Additional possible Chinese badges cannot be recognized reliably from a name or a standalone logo alone. New labels must have real labelled images before being added to a classifier.

Unfinished evidence: own Tashkent training data, phone-screen recapture tests, colour accuracy, unknown-brand evaluation, near-duplicate grouping audit. An 80–90% score on a public dataset does not establish 80–90% accuracy on arbitrary cars or on this exam.

Submission still requires a maximum-six-page PDF, a GitHub URL on page one, source and reproducible training/inference, weights/data links, actual commit history, a midterm tag, and disclosure of AI assistance. Do not fabricate personal data collection, metrics or contributions.
