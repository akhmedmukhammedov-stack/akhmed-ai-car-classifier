"""Report local diagnostics separately for training, validation and test photos."""
import json, socket, time
from PIL import Image
from vision import ROOT, Pipeline

def main():
    def no_network(*args, **kwargs):
        raise AssertionError('Inference attempted network access')
    socket.socket.connect = no_network
    review = json.loads((ROOT/'reports/user_photo_review.json').read_text())
    pipe = Pipeline(); records = []
    split_path=ROOT/'reports/crop_training.json'
    splits={r['path']:r['split'] for r in json.loads(split_path.read_text())['own_split']} if split_path.exists() and pipe.crop_margin else {}
    for row in review['files']:
        with Image.open(ROOT/row['path']) as im:
            started = time.perf_counter(); result = pipe.predict(im)
        main_car = max(result['cars'], key=lambda c: (c['box'][2]-c['box'][0])*(c['box'][3]-c['box'][1]), default=None)
        records.append({**row, 'usage_split':splits.get(row['path'],'diagnostic_only'), 'main_prediction': main_car, 'all_predictions': result['cars'],
                        'seconds': time.perf_counter()-started})
        print(row['path'], row['brand'], main_car, flush=True)
    verified = [r for r in records if r['brand'] is not None]
    report = {'n': len(records), 'verified_brands_n': len(verified),
        'brand_correct': sum(r['main_prediction'] is not None and r['main_prediction']['brand'] == r['brand'] for r in verified),
        'colour_correct': sum(r['main_prediction'] is not None and r['main_prediction']['colour'] == r['colour'] for r in records),
        'network_disabled': True, 'seconds_mean': sum(r['seconds'] for r in records)/len(records),
        'limitations': 'Small convenience sample, primary car scored by largest detection. No complete background-car labels. Two unclear badge labels excluded from brand score. Personal capture not verified. Training/validation images are NOT independent accuracy evidence; see by_split. The tiny local test was inspected before adaptation.',
        'records': records}
    report['by_split']={s:{'n':sum(r['usage_split']==s for r in verified),
        'brand_correct':sum(r['usage_split']==s and r['main_prediction'] is not None and r['main_prediction']['brand']==r['brand'] for r in verified)} for s in sorted({r['usage_split'] for r in verified})}
    (ROOT/'reports/user_photo_results.json').write_text(json.dumps(report, indent=2))
    print({k:v for k,v in report.items() if k != 'records'}, flush=True)

if __name__ == '__main__': main()
