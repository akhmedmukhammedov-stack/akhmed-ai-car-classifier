"""Merge the downloaded CC BY 4.0 car_brand v1 supplement without leaking exact duplicates."""
import csv, hashlib, json
from pathlib import Path
from collections import Counter
from core import safe_extract
ROOT=Path(__file__).resolve().parent
ALIASES={'Bmw':'BMW','Byd':'BYD','Benz':'Mercedes-Benz','hyundai':'Hyundai','nissan':'Nissan','Rolls royce':'Rolls-Royce'}

def main(archive):
    dest=ROOT/'data/extra_cars'; safe_extract(archive,dest)
    rows=list(csv.DictReader((ROOT/'data/manifest.csv').open()))
    old_hashes={r['sha256']:r['brand'] for r in rows}; seen={}; conflicts=[]
    for split in ['test','valid','train']:
        for p in sorted((dest/split).glob('*/*')):
            if p.suffix.lower() not in {'.jpg','.jpeg','.png','.webp'}: continue
            brand=ALIASES.get(p.parent.name,p.parent.name)
            digest=hashlib.sha256(p.read_bytes()).hexdigest()
            if digest in old_hashes or digest in seen:
                previous=old_hashes.get(digest,seen.get(digest))
                if previous!=brand: conflicts.append({'file':str(p),'labels':[previous,brand]})
                continue
            seen[digest]=brand
            rows.append({'path':str(p.relative_to(ROOT)),'brand':brand,'model':'','colour':'',
              'source':'Roboflow pnh car_brand v1 CC BY 4.0','source_split':split,'split':split,'sha256':digest})
    with (ROOT/'data/expanded_manifest.csv').open('w') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)
    summary={'source':'https://universe.roboflow.com/training-kbu2h/car_brand-tuwiw/dataset/1',
      'license':'CC BY 4.0','author':'pnh','total':len(rows),'brands':dict(Counter(r['brand'] for r in rows)),
      'splits':dict(Counter(r['split'] for r in rows)),'skipped_conflicts':conflicts,
      'limitations':'Exact byte duplicates removed; near duplicates still require review. Supplement is not own Tashkent data.'}
    (ROOT/'reports/expanded_data.json').write_text(json.dumps(summary,indent=2))
    print(json.dumps(summary,indent=2))
if __name__=='__main__':
    import sys; main(Path(sys.argv[1]))
