"""Train a new brand head on frozen generic ImageNet features, with held-out evaluation."""
import argparse, csv, json, time, random, copy
from pathlib import Path
import torch
from PIL import Image, ImageOps
from torchvision.models import shufflenet_v2_x1_0, ShuffleNet_V2_X1_0_Weights
from torchvision.models.detection import ssdlite320_mobilenet_v3_large, SSDLite320_MobileNet_V3_Large_Weights
from vision import ROOT, TRANSFORM

def train(epochs=100):
    start=time.time(); random.seed(42); torch.manual_seed(42); torch.set_num_threads(4)
    torch.hub.set_dir(str(ROOT/'models'/'cache'))
    device=torch.device('mps' if torch.backends.mps.is_available() else 'cpu')
    print('Feature extraction device:',device,flush=True)
    rows=list(csv.DictReader((ROOT/'data'/'manifest.csv').open()))
    brands=sorted({r['brand'] for r in rows if r['split']=='train'})
    if len(brands)<2: raise ValueError('At least two brands needed')
    net=shufflenet_v2_x1_0(weights=ShuffleNet_V2_X1_0_Weights.DEFAULT)
    net.fc=torch.nn.Identity(); net=net.eval().to(device)
    sets={}
    for split in ['train','valid','test']:
        subset=[r for r in rows if r['split']==split]
        features=[]; labels=[]
        for offset in range(0,len(subset),32):
            batch=[]
            for row in subset[offset:offset+32]:
                with Image.open(ROOT/row['path']) as im:
                    batch.append(TRANSFORM(ImageOps.exif_transpose(im).convert('RGB')))
                labels.append(brands.index(row['brand']))
            with torch.no_grad(): features.append(net(torch.stack(batch).to(device)).cpu())
            print(f'{split}: {min(offset+32,len(subset))}/{len(subset)}',flush=True)
        sets[split]=(torch.cat(features),torch.tensor(labels))
    # Train only the head; frozen features make this baseline inexpensive on M1.
    head=torch.nn.Linear(1024,len(brands))
    opt=torch.optim.AdamW(head.parameters(),lr=.003,weight_decay=.01)
    x,y=sets['train']; vx,vy=sets['valid']
    counts=torch.bincount(y,minlength=len(brands)).float()
    loss_fn=torch.nn.CrossEntropyLoss(weight=len(y)/(len(brands)*counts))
    best_loss=float('inf'); best=None; history=[]
    for epoch in range(epochs):
        head.train(); order=torch.randperm(len(y)); total=0
        for idx in order.split(128):
            opt.zero_grad(); loss=loss_fn(head(x[idx]),y[idx]); loss.backward(); opt.step()
            total+=float(loss)*len(idx)
        head.eval()
        with torch.no_grad():
            logits=head(vx); val_loss=float(torch.nn.functional.cross_entropy(logits,vy))
            acc=float((logits.argmax(1)==vy).float().mean())
        history.append({'epoch':epoch+1,'train_loss':total/len(y),'valid_loss':val_loss,'valid_accuracy':acc})
        if val_loss<best_loss: best_loss=val_loss; best=copy.deepcopy(head.state_dict())
        if epoch%10==0: print(f'Epoch {epoch+1}: validation accuracy {acc:.3f}',flush=True)
    head.load_state_dict(best); head.eval()
    metrics={}
    for split in ('valid','test'):
        sx,sy=sets[split]
        with torch.no_grad(): pred=head(sx).argmax(1)
        matrix=torch.zeros(len(brands),len(brands),dtype=torch.int64)
        for truth,guess in zip(sy,pred): matrix[truth,guess]+=1
        metrics[split]={'brand_accuracy':float((pred==sy).float().mean()),'n':len(sy),'confusion_matrix':matrix.tolist()}
    torch.save({'brands':brands,'backbone':net.cpu().state_dict(),'head':head.state_dict(),
        'threshold':.55,'architecture':'Frozen ShuffleNetV2 x1.0 + linear brand head'},ROOT/'models'/'brand.pt')
    print('Downloading generic COCO car detector for offline use...',flush=True)
    detector=ssdlite320_mobilenet_v3_large(weights=SSDLite320_MobileNet_V3_Large_Weights.DEFAULT)
    torch.save(detector.state_dict(),ROOT/'models'/'detector.pt')
    report={'brands':brands,'metrics':metrics,'history':history,'seconds':time.time()-start,
        'device':str(device),'epochs':epochs,'learning_rate':.003,'optimizer':'AdamW',
        'augmentation':'None in initial frozen-feature baseline',
        'threshold':.55,'colour_accuracy':None,'phone_test_results':None,
        'limitations':['Crop classifier metrics are not end-to-end street-photo metrics.',
          'Colour heuristic is not yet evaluated.','Confidence threshold is provisional, not calibrated on unknown brands.',
          'Near-duplicate images may inflate validation scores; review before final report.'],
        'parameters':sum(p.numel() for p in net.parameters())+sum(p.numel() for p in head.parameters())}
    (ROOT/'reports'/'training.json').write_text(json.dumps(report,indent=2))
    print(json.dumps(metrics,indent=2),flush=True)
    print('Training complete. Run Start.command. Test with Wi-Fi disabled before class.',flush=True)

if __name__=='__main__':
    ap=argparse.ArgumentParser(); ap.add_argument('--epochs',type=int,default=100); args=ap.parse_args(); train(args.epochs)
